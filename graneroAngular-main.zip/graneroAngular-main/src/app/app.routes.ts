import { Routes } from '@angular/router';


export const routes: Routes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'cmpy',
        loadComponent: () => import('./cmpy/cmpy.component').then(m => m.CmpyComponent)
    },
    {
        path: 'login',
        loadComponent: () => import('./login/login.component').then(m => m.LoginComponent)
    },
    {
        path: 'user',
        loadComponent: () => import('./user/user.component').then(m => m.UserComponent)
    }
];
