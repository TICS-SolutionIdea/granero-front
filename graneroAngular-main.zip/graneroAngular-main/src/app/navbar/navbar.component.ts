import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { MatCardModule } from '@angular/material/card';
import { MyApiService } from '../api/my-api-service.service';
import { FormsModule } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router'; // Importa Router
import { filter } from 'rxjs/operators'; // Asegúrate de importar esto

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, MatCardModule, FormsModule],
  templateUrl: './navbar.component.html', 
  styleUrls: ['./navbar.component.css'],
  providers: [MyApiService] 
})
export class NavbarComponent implements OnInit {
  loginData = {
    Usuario: '',
    Pass: ''
  };
  nombreUsuario: string | null = '';
  usuario: string | null = '';
  showManagementCard: boolean = false;
  showGraneroCard: boolean = false;
  errorMessage: string | null = null; // Propiedad para el mensaje de error
  showLogo: boolean = false;
  


  constructor(
    private apiService: MyApiService,
    private router: Router // Inyecta Router en el constructor
  ) { }

 ngOnInit() {
  this.nombreUsuario = localStorage.getItem('Nombre_Usuario');
  this.usuario = localStorage.getItem('Usuario');

  // Actualiza la visibilidad del logo al iniciar el componente
  this.updateLogoVisibility();
  this.updateCardVisibility();


  // Suscríbete a los cambios de ruta
  this.router.events.pipe(
    filter(event => event instanceof NavigationEnd)
  ).subscribe(() => {
    this.updateLogoVisibility();
    this.updateCardVisibility(); // Actualiza la visibilidad de los cards en los cambios de ruta


    // Verifica si estás en la ruta '/cmpy' o en la ruta de gestión de usuarios
    if (this.router.url === '/cmpy' && this.nombreUsuario && this.usuario) {
      // Mostrar los cards de Gestión de Usuarios y Granero
      this.showManagementCard = true;
      this.showGraneroCard = true;

      // Cierra el modal si está abierto
      const modalElement = document.getElementById('usuarioModal') as HTMLElement;
      if (modalElement) {
        const modal = new (window as any).bootstrap.Modal(modalElement);
        modal.hide();
      }
    } else {
      // Ocultar los cards si no estás en la ruta '/cmpy'
      this.showManagementCard = false;
      this.showGraneroCard = false;
    }
  });
}



  // Función para actualizar la visibilidad del logo
  updateLogoVisibility() {
    const currentUrl = this.router.url;

    // Muestra el logo si la ruta es '/cmpy', ocúltalo si es '/login'
    if (currentUrl.includes('/cmpy')) {
      this.showLogo = true;
    } else if (currentUrl.includes('/login')) {
      this.showLogo = false;
    }
  }

  


  signIn(loginForm: any) {
    console.log("Formulario de inicio de sesión:", loginForm);

    if (loginForm.valid) {
      this.apiService.signIn(this.loginData).subscribe({
        next: (response) => {
          console.log("Inicio de sesión exitoso:", response);
          const userData = response.user;
          console.log("Datos del usuario:", userData);

          // Guardar en localStorage
          localStorage.setItem('Nombre_Usuario', userData.Nombre_Usuario);
          localStorage.setItem('Usuario', userData.Usuario);

          // Actualizar propiedades
          this.nombreUsuario = userData.Nombre_Usuario;
          this.usuario = userData.Usuario;
          this.showManagementCard = false; // Oculta el card de gestión de usuarios
          this.showGraneroCard = false; // Oculta el card del granero

          // Mostrar datos guardados en consola
          console.log("Nombre_Usuario guardado:", this.nombreUsuario);
          console.log("Usuario guardado:", this.usuario);

          // Limpiar el mensaje de error
          this.errorMessage = null;

          // Cierra el modal de inicio de sesión
          const modalElement = document.getElementById('usuarioModal') as HTMLElement;
          const modal = new (window as any).bootstrap.Modal(modalElement);
          modal.hide();

          // Redirigir a la ruta '/cmpy' después de autenticar al usuario
          this.router.navigate(['/cmpy']).then(success => {
            if (success) {
              console.log('Redirección exitosa a /cmpy');
            } else {
              console.error('Error al redirigir a /cmpy');
            }
          });
        },
        error: (error) => {
          console.error("Error al iniciar sesión:", error);
          // Ajusta la forma de obtener el mensaje de error según la estructura del error
          this.errorMessage = error.error?.message || "Contraseña incorrecta. Por favor, inténtalo de nuevo.";
        }
      });
    } else {
      console.warn("Formulario de inicio de sesión inválido");
      this.errorMessage = "Por favor, completa todos los campos requeridos.";
    }

    // Mostrar modal de Bootstrap
    const signOutModalElement = document.getElementById('signOutModalLogin') as HTMLElement;
    const signOutModal = new (window as any).bootstrap.Modal(signOutModalElement);
    signOutModal.show();

    // Redirigir después de cerrar el modal
    signOutModalElement.addEventListener('hidden.bs.modal', () => {
      this.router.navigate(['/cmpy']);
    });
  }

  signOut() {
    // Eliminar datos del almacenamiento local
    localStorage.removeItem('Nombre_Usuario');
    localStorage.removeItem('Usuario');
    this.nombreUsuario = null;
    this.usuario = null;
    this.showManagementCard = false;
    this.showGraneroCard = false;
  
    // Mostrar el modal de Bootstrap
    const signOutModalElement = document.getElementById('signOutModal') as HTMLElement;
    if (signOutModalElement) {
        const signOutModal = new (window as any).bootstrap.Modal(signOutModalElement);
        signOutModal.show();
  
        // Redirigir después de cerrar el modal
        signOutModalElement.addEventListener('hidden.bs.modal', () => {
            this.router.navigate(['/login']).then(success => {
                if (success) {
                    console.log('Redirección exitosa a /login');
                } else {
                    console.error('Error al redirigir a /login');
                }
            });
        });
    } else {
        console.error('No se encontró el modal de cierre de sesión');
        // Redirigir de inmediato si no se encuentra el modal
        this.router.navigate(['/login']).then(success => {
            if (success) {
                console.log('Redirección exitosa a /login');
            } else {
                console.error('Error al redirigir a /login');
            }
        });
    }
  }

  navigateToUser() {
    this.router.navigate(['/user']).then(success => {
      if (success) {
        console.log('Redirección exitosa a /user');
      } else {
        console.error('Error al redirigir a /user');
      }
    });
  }

  navigateToGranero() {
    this.router.navigate(['/cmpy']).then(success => {
      if (success) {
        console.log('Redirección exitosa a /cmpy');
      } else {
        console.error('Error al redirigir a /cmpy');
      }
    });
  }

  private updateCardVisibility() {
    const isAuthenticated = !!this.nombreUsuario && !!this.usuario;
    this.showManagementCard = isAuthenticated && this.router.url === '/cmpy';
    this.showGraneroCard = isAuthenticated && (this.router.url === '/cmpy' || this.router.url === '/user');
  }
  isPasswordVisible: boolean = false;

  togglePasswordVisibility() {
    this.isPasswordVisible = !this.isPasswordVisible;
    const passwordField = document.getElementById('usuarioPassword') as HTMLInputElement;
    if (passwordField) {
      passwordField.type = this.isPasswordVisible ? 'text' : 'password';
    }
  }
}
