import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MyApiService } from '../api/my-api-service.service';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
declare var bootstrap: any;

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [MatTableModule, CommonModule, HttpClientModule, MatIconModule, MatCardModule, MatFormFieldModule, FormsModule, MatDatepickerModule, MatInputModule, MatNativeDateModule],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [MyApiService, DatePipe, Location] // Añadir DatePipe aquí
})
export class UserComponent {
  displayedColumns: string[] = ['actions', 'ID_Usuario', 'Nombre_Usuario', 'Usuario', 'Correo_Electronico', 'Rol', 'Admin', 'TablaEmpresas', 'Empleados', 'Permisos', 'UsuariosData', 'Mostrar_Cinta_Opciones', 'Activar_Shift', 'created_at', 'updated_at'];
  dataSource: any[] = [];
  searchTerm: string = '';
  searchTerm1: string = '';
  originalDataSource: any[] = []; // Para guardar los datos originales

  newUser: User = {
    ID_Usuario: 0,
    Nombre_Usuario: '',
    Usuario: '',
    Pass: '',
    Rol: '',
    Admin: false,
    TablaEmpresas: false,
    Empleados: false,
    Permisos: false,
    UsuariosData: false,
    Mostrar_Cinta_Opciones: false,
    Activar_Shift: false,
    Correo_Electronico: '', // Campo Correo_Electronico añadido
    created_at: '',
    updated_at: ''
  };
  

  constructor(private apiService: MyApiService) { }

  ngOnInit() {
    this.loadData();
  }

  applyFilter1() {
    const filterValue = this.searchTerm1.trim().toLowerCase();
    if (filterValue === '') {
      // Restaurar dataSource a su estado original
      this.dataSource = [...this.originalDataSource];
    } else {
      // Filtrar dataSource basado en el valor de búsqueda
      this.dataSource = this.originalDataSource.filter((item: any) =>
        item.Nombre_Usuario.toLowerCase().includes(filterValue)
      );
    }
  }

  loadData() {
    this.apiService.getUsers().subscribe({
      next: (data) => {
        console.log("Datos de usuarios: ", data);
        this.dataSource = data;
        this.originalDataSource = data; // Guardar datos originales
      },
      error: (error) => {
        console.error("Error al cargar los datos de usuarios: ", error);
        this.dataSource = [];
      }
    });
  }

  saveData(element: User) {
    element.Rol = element.Admin ? 'Admin' : 'Employee';
    this.apiService.postUser(element).subscribe({
      next: (response) => {
        console.log("Usuario guardado correctamente: ", response);
        this.loadData(); // Recargar datos después de guardar
      },
      error: (error) => {
        console.error("Error al guardar el usuario: ", error);
      }
    });
  }

  saveNewUser(userForm: any) {
    if (userForm.valid) {
      this.newUser.Rol = this.newUser.Admin ? 'Admin' : 'Employee';
  
      if (this.newUser.ID_Usuario > 0) {
        this.editUser(this.newUser, userForm);
      } else {
        const userToSave = {
          Nombre_Usuario: this.newUser.Nombre_Usuario,
          Usuario: this.newUser.Usuario,
          Pass: this.newUser.Pass,
          Rol: this.newUser.Rol,
          Admin: this.newUser.Admin,
          TablaEmpresas: this.newUser.TablaEmpresas,
          Empleados: this.newUser.Empleados,
          Permisos: this.newUser.Permisos,
          UsuariosData: this.newUser.UsuariosData,
          Mostrar_Cinta_Opciones: this.newUser.Mostrar_Cinta_Opciones,
          Activar_Shift: this.newUser.Activar_Shift,
          Correo_Electronico: this.newUser.Correo_Electronico // Añadir Correo_Electronico
        };
  
        console.log("Datos que se enviarán al API:", userToSave);
        this.apiService.postUser(userToSave).subscribe({
          next: (response) => {
            console.log("Nuevo usuario guardado correctamente: ", response);
            this.loadData();
            this.closeModal();
            this.resetForm(userForm);
            this.showRegisterConfirmationModal();
          },
          error: (error) => {
            console.error("Error al guardar el nuevo usuario: ", error);
          }
        });
      }
    } else {
      console.warn("Formulario inválido");
    }
  }

  showRegisterConfirmationModal() {
    const modalElement = document.getElementById('registerConfirmationModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }

  editUser(user: User, userForm: any) {
    const userToEdit = {
      Nombre_Usuario: user.Nombre_Usuario,
      Usuario: user.Usuario,
      Pass: user.Pass,
      Rol: user.Rol,
      Admin: user.Admin,
      TablaEmpresas: user.TablaEmpresas,
      Empleados: user.Empleados,
      Permisos: user.Permisos,
      UsuariosData: user.UsuariosData,
      Mostrar_Cinta_Opciones: user.Mostrar_Cinta_Opciones,
      Activar_Shift: user.Activar_Shift,
      Correo_Electronico: user.Correo_Electronico // Añadir Correo_Electronico
    };
  
    console.log("Datos que se enviarán al API para editar:", userToEdit);
    this.apiService.putUser(userToEdit, user.ID_Usuario).subscribe({
      next: (response) => {
        console.log("Usuario editado correctamente: ", response);
        this.loadData();
        this.closeModal();
        this.resetForm(userForm);
        this.showEditConfirmationModal();
      },
      error: (error) => {
        console.error("Error al editar el usuario: ", error);
      }
    });
  }
  showEditConfirmationModal() {
    const modalElement = document.getElementById('editConfirmationModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }

  resetForm(userForm: any) {
    this.newUser = {
      ID_Usuario: 0,
      Nombre_Usuario: '',
      Usuario: '',
      Pass: '',
      Rol: '',
      Admin: false,
      TablaEmpresas: false,
      Empleados: false,
      Permisos: false,
      UsuariosData: false,
      Mostrar_Cinta_Opciones: false,
      Activar_Shift: false,
      Correo_Electronico: '', // Añadir Correo_Electronico
      created_at: '',
      updated_at: ''
    };
    userForm.resetForm();
  }
  

  openModal(id?: number) {
    if (id) {
      this.apiService.getUserById(id).subscribe({
        next: (data) => {
          this.newUser = data;
          const modal = new bootstrap.Modal(document.getElementById('addUserModal'));
          modal.show();
        },
        error: (error) => {
          console.error("Error al obtener los datos del usuario: ", error);
        }
      });
    } else {
      this.newUser = {
        ID_Usuario: 0,
        Nombre_Usuario: '',
        Usuario: '',
        Pass: '',
        Rol: '',
        Admin: false,
        TablaEmpresas: false,
        Empleados: false,
        Permisos: false,
        UsuariosData: false,
        Mostrar_Cinta_Opciones: false,
        Activar_Shift: false,
        created_at: '',
        updated_at: ''
      };
      const modal = new bootstrap.Modal(document.getElementById('addUserModal'));
      modal.show();
    }
  }

  closeModal() {
    const modalElement = document.getElementById('addUserModal');
    const modal = bootstrap.Modal.getInstance(modalElement);
    modal.hide();
  }

  toggleRow(element: User) {
    element.isExpanded = !element.isExpanded;
  }

  deleteUser(id: number) {
    this.apiService.deleteUser(id).subscribe({
      next: (response) => {
        console.log("Usuario eliminado correctamente: ", response);
        this.loadData(); // Recargar datos después de eliminar
        this.showConfirmationModal(); // Mostrar el modal de confirmación
      },
      error: (error) => {
        console.error("Error al eliminar el usuario: ", error);
      }
    });
  }
  
  showConfirmationModal() {
    const modalElement = document.getElementById('deleteConfirmationModal');
    if (modalElement) {
      const modal = new bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  

  addUser() {
    this.openModal();
  }
}

export interface User {
  ID_Usuario: number;
  Nombre_Usuario: string;
  Usuario: string;
  Pass: string;
  Rol: string;
  Admin: boolean;
  TablaEmpresas: boolean;
  Empleados: boolean;
  Permisos: boolean;
  UsuariosData: boolean;
  Mostrar_Cinta_Opciones: boolean;
  Activar_Shift: boolean;
  Correo_Electronico?: string; // Campo Correo_Electronico añadido
  created_at?: string;
  updated_at?: string;
  isExpanded?: boolean;
}


const USER_DATA: User[] = [
  // Aquí puedes agregar datos de prueba
];
