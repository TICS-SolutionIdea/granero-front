export interface TPersona {
    p : number;
    of: number;
    tLctn: any; // O especifica un tipo más adecuado si conoces la estructura
    out: boolean;
    nombre: string;
    segundo: string;
    aPaterno: string;
    aMaterno: string;
    prefijo: string;
    sufijo: any;
    puesto: string;
    ext: any;
    linkedin: any;
    tCel1: string;
    tSwB: string;
    tOf: string;
    tOf2: any;
    tAssist: any;
    tCel2: any;
    tHome: any;
    tFax: any;
    eMailw: any;
    eMailp: any;
    elec: any;
    hcPy: any;
    asistente: any;
    when: any;
    where: any;
    pe: boolean;
    bs: boolean;
    ms: boolean;
    phD: boolean;
    notas: string;
    created_By: any;
    created: any;
    updated: string;
    updated_By: string;
  }
  


  export interface ApiResponseTPersona {
  personas: TPersona[];
}
