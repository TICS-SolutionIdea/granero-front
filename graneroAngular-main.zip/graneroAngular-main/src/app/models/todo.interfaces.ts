// Interfaz para un solo item de ToDo
export interface ToDo {
    A: number; // Ajusta el tipo según sea necesario
    P: number;
    Du: string; // Ajusta el tipo según sea necesario
    Prdd: string; // Ajusta el tipo según sea necesario
    Tarea: string;
    Descripcion: string;
    Seguimiento: string; // Ajusta el tipo según sea necesario
    Creado: string | null; // Usa 'string | null' si la fecha puede ser nula
    Limite: string | null; // Usa 'string | null' si la fecha puede ser nula
    Terminado: string | null; // Usa 'string | null' si la fecha puede ser nula
    Ao: string; // Ajusta el tipo según sea necesario
    Bo: string; // Ajusta el tipo según sea necesario
    Co: string; // Ajusta el tipo según sea necesario
    Do: string; // Ajusta el tipo según sea necesario
    Eo: string; // Ajusta el tipo según sea necesario
    Fo: string; // Ajusta el tipo según sea necesario
    Go: string; // Ajusta el tipo según sea necesario
    Ho: string; // Ajusta el tipo según sea necesario
    Io: string; // Ajusta el tipo según sea necesario
    PCS: string; // Ajusta el tipo según sea necesario
    Estado: string;
    Created_By: string | null; // Usa 'string | null' si puede ser nulo
    Created: string | null; // Usa 'string | null' si la fecha puede ser nula
    Updated_By: string | null; // Usa 'string | null' si puede ser nulo
    Updated: string | null; // Usa 'string | null' si la fecha puede ser nula
  }
  
  // Interfaz para la respuesta de la API
  export interface ApiResponseToDo {
    todos: ToDo[];
  }
  