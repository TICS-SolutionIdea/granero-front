export interface DataTableItemCmpy {
    o: number;
    nombre: string;
    type: string;
  }
  
  export interface TCompany {
    o: number;
    nombre: string;
    rs: number | null;
    ac: boolean;
    type: string;
    industry: string;
    serPro: string | null;
    origen: string | null;
    url: string | null;
    linkedin: string | null;
    eMail: string | null;
    fnd: number;
    emplea: number;
    ventas: number;
    ref: string | null;
    nota: string | null;
    company_State: string | null;
    shared_With: string | null;
    created_By: string;
    Created: string;
    updated: string;
    updated_By: string;
    upsize_ts: string;
  }
  
  export interface ApiResponseTCompany {
    companies: TCompany[]; // Array de objetos TCompany.
  }
  