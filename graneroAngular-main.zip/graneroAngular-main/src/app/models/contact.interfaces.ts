export interface TContact {
    l: number;
    p: number;
    tPrsn: any; // Asigna un tipo más específico si conoces la estructura, o déjalo como 'any' si es variable.
    Fecha: any;
    ow: string;
    comTy: string;
    contenido: string;
    segui: any; // Similar a tPrsn, define el tipo específico si es conocido o usa 'any'.
    created_By: any; // Puede ser 'string' si siempre se espera un nombre o 'null' si puede ser nulo.
    created: string | null; // Usa 'string | null' si la fecha puede ser nula.
    updated: string | null;
    updated_By: any;
    upsize_ts: string;
}


export interface ApiResponseTContact {
    contacts: TContact[];
}
