export interface TLocation {
    of: number;
    o: number;
    cmpyId?: number;  // Agrega la propiedad cmpyId opcionalmente
    tCmpy: any;  // Asumiendo que este campo puede ser más complejo o siempre null.
    name: string;
    url: any;    // Tipo 'any' si el valor puede ser null o un string.
    swb: string;
    swB2: string;
    domicilio: string;
    colonia: any;  // Tipo 'any' si el valor puede ser null o un string.
    city: string;
    state: string;
    zip: string | null;
    gps: any;      // Tipo 'any' si el valor puede ser null o un string.
    matriz: number;
    pais: string;
    mapEP: string;
    nota: any;     // Tipo 'any' si el valor puede ser null o un string.
    created_By: any;  // Tipo 'any' si el valor puede ser null o un string.
    created: any;     // Tipo 'any' si el valor puede ser null o un string.
    updated: string;
    updated_By: string;
    upsize_ts: string;
  }

  
  export interface ApiResponseTLocation {
    locations: TLocation[];  // Array de objetos TLocation.
  }
  