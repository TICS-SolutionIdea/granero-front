import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MyApiService {

  private CmpyApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCmpy';
  //url de cmpy inactivo
  private CmpyApiInactiveUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCmpy/inactive';
  private LctnApiByIdUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tLctn/o';
  private LctnApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tLctn';
  private PrsnApiByIdUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tPrsn/of';
  private PrsnApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tPrsn';
  private ComApiByIdUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCom';
  private ComApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCom';
  private UserApiUrl ='https://website-5d5419ed.zat.yfm.mybluehost.me/api/tusers';
  private siginApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api';
  private ToDoApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/todos';
  private CmpydApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCmpy';
  private LctndApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tLctn';
  private PrsndApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tPrsn';
  private ComdApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/tCom';
  private ToDodApiUrl = 'https://website-5d5419ed.zat.yfm.mybluehost.me/api/todos';




  constructor(private http: HttpClient) { }

  // get activo con parámetro opcional
  getDatosCmpy(sharedWith?: string): Observable<any> {
    let params = new HttpParams();
    if (sharedWith) {
      params = params.set('shared_with', sharedWith);
    }
    // console.log de la url y los parámetros
    console.log("URL de cmpy: " + this.CmpyApiUrl, "Params: " + params.toString());

    return this.http.get<any>(this.CmpyApiUrl, { params }).pipe(
      map(response => response.data) // Extraer solo los datos de la clave 'data'
    );
  }

// get inactivo con parámetro opcional
  getDatosCmpyInac(sharedWith?: string): Observable<any> {
    let params = new HttpParams();
    if (sharedWith) {
      params = params.set('shared_with', sharedWith);
    }
    // console.log de la url y los parámetros
    console.log("URL de cmpy: " + this.CmpyApiInactiveUrl, "Params: " + params.toString());

    return this.http.get<any>(this.CmpyApiInactiveUrl, { params }).pipe(
      map(response => response.data) // Extraer solo los datos de la clave 'data'
    );
  }

  //get sin parámetro
  getDatosFullCmpy(): Observable<any> {
    return this.http.get(this.CmpyApiUrl);
  }
  
  getLctnById(id: number): Observable<any> {
    return this.http.get(`${this.LctnApiByIdUrl}/${id}`);
  }
  getPrsnById(id: number): Observable<any> {
    return this.http.get(`${this.PrsnApiByIdUrl}/${id}`);
  }

  getComById(id: number): Observable<any> {
    return this.http.get(`${this.ComApiByIdUrl}/${id}`);
  }
  getUsers(): Observable<any> {
    return this.http.get(this.UserApiUrl);
  }
  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.UserApiUrl}/${id}`);
  }

  getToDo(): Observable<any> {
    return this.http.get(this.ToDoApiUrl);
  }

  getToDoById(id: number): Observable<any> {
    //console.log de la url
    console.log("url de todo: "+`${this.ToDoApiUrl}/${id}`);
    return this.http.get(`${this.ToDoApiUrl}/${id}`);
  }

  // put
  putDatosCmpy(datos: any, id: number): Observable<any> {
    return this.http.put(`${this.CmpyApiUrl}/${id}`, datos);
  }
  putDatosLctn(datos: any, id: number): Observable<any> {
    return this.http.put(`${this.LctnApiUrl}/${id}`, datos);
  }
  putDatosPrsn(datos: any, id: number): Observable<any> {
    return this.http.put(`${this.PrsnApiUrl}/${id}`, datos);
  }
  putDatosCom(datos: any, id: number): Observable<any> {
    return this.http.put(`${this.ComApiUrl}/${id}`, datos);
  }
  putUser(datos: any, id: number): Observable<any> {
    return this.http.put(`${this.UserApiUrl}/${id}`, datos);
  }
putToDoById(datos: any, id: number): Observable<any> {
  return this.http.put(`${this.ToDoApiUrl}/${id}`, datos);
}
  

  // post
  postDatosCmpy(datos: any): Observable<any> {
    return this.http.post(this.CmpyApiUrl, datos);
  }
  postDatosLctn(datos: any): Observable<any> {
    return this.http.post(this.LctnApiUrl, datos);
  }
  postDatosPrsn(datos: any): Observable<any> {
    return this.http.post(this.PrsnApiUrl, datos);
  }
  postDatosCom(datos: any): Observable<any> {
    return this.http.post(this.ComApiUrl, datos);
  }
  postUser(datos: any): Observable<any> {
    return this.http.post(this.UserApiUrl, datos);
  }
  postToDoById(datos: any): Observable<any> {
    return this.http.post(this.ToDoApiUrl, datos);
  }
  // signin
  signIn(datos: any): Observable<any> {
    return this.http.post(`${this.siginApiUrl}/signin`, datos);
  }

  // delete
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.UserApiUrl}/${id}`);
  }
  deleteCmpy(id: number): Observable<any> {
    return this.http.delete(`${this.CmpydApiUrl}/${id}`);
  }
  deleteLctn(id: number): Observable<any> {
    return this.http.delete(`${this.LctndApiUrl}/${id}`);
  }
  deletePrsn(id: number): Observable<any> {
    return this.http.delete(`${this.PrsndApiUrl}/${id}`);
  } 
  deleteCom(id: number): Observable<any> {
    return this.http.delete(`${this.ComdApiUrl}/${id}`);
  }
  deletetoDo(id: number): Observable<any> {
    return this.http.delete(`${this.ToDodApiUrl}/${id}`);
  }
 
 
 
  

  // patch
  patchAc(id: number, acValue: boolean): Observable<any> {
    const body = {
      Ac: acValue
    };

    return this.http.patch(`${this.CmpyApiUrl}/${id}/ac`, body);
  }
}
