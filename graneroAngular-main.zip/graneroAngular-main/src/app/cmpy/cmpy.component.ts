import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MyApiService } from '../api/my-api-service.service';
import { MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { DataTableItemCmpy, TCompany, ApiResponseTCompany } from '../models/company.interfaces';
import { TLocation, ApiResponseTLocation } from '../models/location.interfaces';
import { TPersona, ApiResponseTPersona } from '../models/person.interfaces';
import { TContact, ApiResponseTContact } from '../models/contact.interfaces';
import { ToDo, ApiResponseToDo } from '../models/todo.interfaces'; // Asegúrate de que esta ruta sea correcta
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { DatePipe } from '@angular/common';
import { Location } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import Swal from 'sweetalert2';
import tippy from 'tippy.js'; // Importar Tippy.js
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';




import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-cmpy',
  standalone: true,
  imports: [MatTableModule, CommonModule, MatTooltipModule, HttpClientModule, MatIconModule, MatCardModule, MatFormFieldModule, FormsModule, MatDatepickerModule, MatInputModule, MatNativeDateModule,
      MatSlideToggleModule,MatExpansionModule,MatCheckboxModule,MatButtonModule,MatMenuModule, MatPaginatorModule
    ],
  templateUrl: './cmpy.component.html',
  styleUrls: ['./cmpy.component.css'],
  providers: [MyApiService, DatePipe,Location,

  ], 
})
export class CmpyComponent implements OnInit , AfterViewInit {
  dataSource!: MatTableDataSource<any>;
  @ViewChild('paginatorCmpy') paginatorCmpy!: MatPaginator;

  originalDataSource: any[] = []; // Para guardar los datos originales
  dataSourceLctnById: ApiResponseTLocation[] = [];
  originalDataSourceLctnById: ApiResponseTLocation[] = [];
  dataSourcePrsnById: ApiResponseTPersona[] = [];
  originalDataSourcePrsnById: ApiResponseTPersona[] = [];
  dataSourceComById: ApiResponseTContact[] = [];
  originalDataSourceComById: ApiResponseTContact[] = [];
  dataSourceToDoById: ApiResponseToDo[] = [];
  originalDataSourceToDoById: ApiResponseToDo[] = [];
  currentExpandedToDo: any = null;
  cmpyId: number | null = null;
  totalCmpyRegistros: number = 0;

  




  dataSourceTest1: DataTableItemCmpy[] = [];
  searchTerm: string = '';
  searchTerm1: string = '';
  searchTerm2: string = '';
  searchTerm3: string = '';
  searchTerm4: string = '';
  nuevoElemento: any = {}; 
  private _isActive: boolean = true;

  selectedInitials: string = ''; // Declara la variable selectedInitials

  sharedWithOptions: string[] = [
    'ety', 'aty', 'dcj', 'cjr', 'dso', 'lep', 'nty', 'dair', 'bjr', 'eca'
  ];
  selectedSharedWithOptions: string[] = [];

  element: any; // Para el formulario de agregar

  constructor(
    private apiService: MyApiService, 
    private cdr: ChangeDetectorRef,
    private datePipe: DatePipe,
    private location: Location,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.loadData();
    this.loadTestData();
    this.element = {
      // Inicializa las demás propiedades según sea necesario
      elementShared: {
        option5: false,
        option6: false,
        option7: false,
        option8: false,
        option9: false,
        option10: false,
        option11: false,
      },
    };
  }

  ngAfterViewInit() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginatorCmpy;
    }
  }
  
  
  toggleAc(element: any) {
    element.ac = !element.ac;
  }

  get isActive(): boolean {
    return this._isActive;
  }

  set isActive(value: boolean) {
    this._isActive = value;
    this.loadData();
  }

  // Función para obtener el total de registros
getTotalRegistros(): number {
  return this.dataSource ? this.dataSource.data.length : 0;
}

loadData() { 
  const usuario = localStorage.getItem('Usuario') || undefined;

  if (this.isActive) {
    console.log("is active es true");

    this.apiService.getDatosCmpy(usuario).subscribe({
      next: (data) => {
        console.log("Data from API:", data);
        if (data.length > 0) {
          this.originalDataSource = data.map((item: any) => {
            const elementShared = this.getElementSharedState(item.Shared_With);
            return { 
              ...item, 
              isExpanded: false, 
              elementShared: elementShared || {
                option5: false,
                option6: false,
                option7: false,
                option8: false,
                option9: false,
                option10: false,
                option11: false,
              }
            };
          });
          this.dataSource = new MatTableDataSource<any>(this.originalDataSource);

          // Asigna el paginador aquí
          this.dataSource.paginator = this.paginatorCmpy;

          // Llama a la función para obtener el total de registros
          this.totalCmpyRegistros = this.getTotalRegistros();

          // Si usas ordenamiento, también asigna el MatSort aquí
          // this.dataSource.sort = this.sortCmpy;

          this.cdr.detectChanges();
        } else {
          this.originalDataSource = [];
        }
      },
      error: (error) => {
        console.error('No hay registro', error);
        this.dataSource = new MatTableDataSource<any>([]);
        this.originalDataSource = [];
        this.dataSource.paginator = this.paginatorCmpy; // Asegúrate de asignar el paginador incluso si no hay datos
        this.totalCmpyRegistros = 0; // Si hay un error, el total de compañías es 0
      }
    });
  } 
  else {
    console.log("is active es false");
    this.apiService.getDatosCmpyInac(usuario).subscribe({
      next: (data) => {
        console.log("Data from API:", data);
        if (data.length > 0) {
          this.originalDataSource = data.map((item: any) => {
            const elementShared = this.getElementSharedState(item.Shared_With);
            return { 
              ...item, 
              isExpanded: false, 
              elementShared: elementShared
            };
          });
          this.dataSource = new MatTableDataSource(this.originalDataSource);
          this.dataSource.paginator = this.paginatorCmpy;

          // Llama a la función para obtener el total de registros
          this.totalCmpyRegistros = this.getTotalRegistros();

          this.cdr.detectChanges();
        } else {
          this.totalCmpyRegistros = 0; // Si no hay datos, total es 0
        }
      },
      error: (error) => {
        console.error('No hay registro', error);
        this.dataSource = new MatTableDataSource<any>(this.originalDataSource);
        this.totalCmpyRegistros = 0; // Si hay un error, el total de compañías es 0
      }
    });
  }
}

  
  
// Método que crea el estado de los checkboxes basado en el valor de Shared_With
getElementSharedState(sharedWith: string) {
  const sharedArray = sharedWith ? sharedWith.split(/[,;]/) : [];

  return {
    option6: sharedArray.includes('cjr'),  // cjr
    option7: sharedArray.includes('dso'),  // dso
    option8: sharedArray.includes('lep'),  // lep
    option9: sharedArray.includes('nty'),  // nty
    option10: sharedArray.includes('dair'),  // dair
    option11: sharedArray.includes('eca'),   // eca
  };
}


createSharedWithString(sharedState: any): string {
  const sharedWithArray = [];
  if (sharedState.option6) sharedWithArray.push('cjr');
  if (sharedState.option7) sharedWithArray.push('dso');
  if (sharedState.option8) sharedWithArray.push('lep');
  if (sharedState.option9) sharedWithArray.push('nty');
  if (sharedState.option10) sharedWithArray.push('dair');
  if (sharedState.option11) sharedWithArray.push('eca');
  
  return sharedWithArray.join(',');
}

  // Método para inicializar los checkboxes al cargar Shared_With
  initializeSelections(sharedWith: string) {
    if (!sharedWith) {
      console.error("Shared_With está vacío o no es válido");
      return;
    }
  
    // Dividir la cadena utilizando tanto comas como punto y coma
    const sharedArray = sharedWith.split(/[,;]/);  // Dividir por coma o punto y coma
  
    
    this.elementShared.option6 = sharedArray.includes('cjr');
    this.elementShared.option7 = sharedArray.includes('dso');
    this.elementShared.option8 = sharedArray.includes('lep');
    this.elementShared.option9 = sharedArray.includes('nty');
    this.elementShared.option10 = sharedArray.includes('dair');
    this.elementShared.option11 = sharedArray.includes('eca');
  
    console.log("Opciones seleccionadas tras inicialización:", this.elementShared);
  }
  
  
  saveDataComp() {
    if (this.dummyData.length > 0) {
      const element = this.dummyData[0]; // O el elemento específico que quieras enviar
  
      const nombreUsuario = localStorage.getItem('Usuario');
      if (!nombreUsuario) {
        console.error('No se encontró Usuario en localStorage');
        return;
      }
  
      // Asegurarse de que element.Shared_With está actualizado
      if (!element.Shared_With) {
        this.updateSelection(element);
      }
  
      // Crear la lista de Shared_With incluyendo el usuario actual
      const sharedWithList = [nombreUsuario, ...element.Shared_With.split(';')];
  
      // Eliminar duplicados
      const uniqueSharedWithList = Array.from(new Set(sharedWithList));
  
      // Reconstruir el string de Shared_With
      const Shared_With = uniqueSharedWithList.join(';');
  
      const datosAGuardar = {
        Nombre: element.Nombre,
        Rs: element.Rs,
        Ac: 1,
        Type: element.Type,
        Industry: element.Industry,
        SerPro: element.SerPro,
        Origen: element.Origen,
        URL: element.URL,
        Linkedin: element.Linkedin,
        eMail: element.eMail,
        Fnd: element.Fnd,
        Emplea: element.Emplea,
        Ventas: element.Ventas,
        Ref: element.Ref,
        Nota: element.Nota,
        Company_State: element.Company_State,
        Shared_With: Shared_With,
        Created_By: nombreUsuario,
        Created: element.Created || new Date(),
      };
  
      console.log('Datos a guardar:', datosAGuardar);
      this.apiService.postDatosCmpy(datosAGuardar).subscribe({
        next: (response: any) => {
          console.log('Datos guardados:', response);
  
          // Mostrar la alerta de éxito en el centro
          Swal.fire({
            position: "center",
            icon: "success",
            title: "Compañias: Datos guardados correctamente",
            showConfirmButton: false,
            timer: 1500
          });
  
          // Recargar la página al finalizar
          setTimeout(() => {
            window.location.reload();
          }, 1500);  // Esperar a que la alerta termine antes de recargar
        },
        error: (error) => {
          console.error('Error al guardar los datos:', error);
  
          // Mostrar alerta de error
          Swal.fire({
            position: "center",
            icon: "error",
            title: "Error al guardar los datos",
            showConfirmButton: true
          });
        }
      });
    } else {
      console.error('No hay datos en dummyData para guardar');
    }
  }
  
  


  saveDataLctn() {
    if (this.dummyData2.length > 0) {
      const lctn = this.dummyData2[0]; 
      const idO = localStorage.getItem('cmpyId');
      const idO2 = idO ? parseInt(idO, 10) : null;
      const datosAGuardar = {
        O: idO,
        Name: lctn.Nombre,
        URL: lctn.URL,
        SWB: lctn.SWB,
        SWB2: lctn.SWB2,
        Domicilio: lctn.Domicilio,
        Colonia: lctn.Colonia,
        City: lctn.City,
        State: lctn.State,
        Zip: lctn.Zip,
        GPS: lctn.GPS,
        Pais: lctn.Pais,
       
      };
  
      console.log('Datos a guardar de lctn:', datosAGuardar);
  
      this.apiService.postDatosLctn(datosAGuardar).subscribe({
        next: (response: any) => {
          console.log('Datos guardados de lctn:', response);
  
          if (idO2 !== null) {
            this.loadDataLctnById(idO2);
          } else {
            console.error('ID no encontrado en localStorage');
            window.location.reload();
          }
  
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Ubicaciones: Datos guardados exitosamente',
            showConfirmButton: false,
            timer: 1500
          });
  
          // Limpiar campos después de guardar
          this.dummyData2 = [{
            Nombre: '',
            URL: '',
            SWB: '',
            SWB2: '',
            Domicilio: '',
            Colonia: '',
            City: '',
            State: '',
            Pais: ''
          }];
        },
        error: (error) => {
          console.error('Error al guardar los datos de lctn:', error);
  
          Swal.fire({
            icon: 'error',
            title: 'Error al guardar',
            text: 'Ocurrió un error al guardar los datos.',
          });
        }
      });
    } else {
      console.error('No hay datos en dummyData2 para guardar');
  
      Swal.fire({
        icon: 'info',
        title: 'No hay datos',
        text: 'No hay datos para guardar.',
      });
    }
  }
  
  
  

  saveDataPrsnn() {
    if (this.dummyData3.length > 0) {
      const prsn = this.dummyData3[0]; 
      const idOf = localStorage.getItem('idOf');
      const idOf2 = idOf ? parseInt(idOf, 10) : null;
      const datosAGuardar = {
        Of: idOf,
        Nombre: prsn.Nombre,
        Segundo: prsn.Segundo,
        APaterno: prsn.APaterno,
        AMaterno: prsn.AMaterno,
        Prefijo: prsn.Prefijo,
        Sufijo: prsn.Sufijo,
        Puesto: prsn.Puesto,
        Ext: prsn.Ext,
        Linkedin: prsn.Linkedin,
        TCel1: prsn.TCel1,
        TSwB: prsn.TSwB,
        TOf: prsn.TOf,
        TAssist: prsn.TAssist,
        TOf2: prsn.TOf2,
        T: prsn.T,
        TCel2: prsn.TCel2,
        THome: prsn.THome,
        TFax: prsn.TFax,
        eMailw: prsn.eMailw,
        eMailp: prsn.eMailp,
        Asistente: prsn.Asistente,
        When: prsn.When,
        Where: prsn.Where,
      };
  
      console.log('Datos a guardar de prsn:', datosAGuardar);
  
      this.apiService.postDatosPrsn(datosAGuardar).subscribe({
        next: (response: any) => {
          console.log('Datos guardados de prsn:', response);
  
          if (idOf2 !== null) {
            this.loadDataPrsnById(idOf2);
          } else {
            console.error('ID no encontrado en localStorage');
            window.location.reload();
          }
  
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Personas: Datos guardados exitosamente',
            showConfirmButton: false,
            timer: 3500
          });
  
          // Limpiar los campos después de guardar
          this.dummyData3 = [{
            Nombre: '',
            Segundo: '',
            APaterno: '',
            AMaterno: '',
            Prefijo: '',
            Sufijo: '',
            Puesto: '',
            Ext: '',
            Linkedin: '',
            TCel1: '',
            TSwB: '',
            TOf: '',
            TAssist: '',
            TOf2: '',
            T: '',
            TCel2: '',
            THome: '',
            TFax: '',
            eMailw: '',
            eMailp: '',
            Asistente: '',
            When: '',
            Where: ''
          }];
        },
        error: (error) => {
          console.error('Error al guardar los datos:', error);
  
          Swal.fire({
            icon: 'error',
            title: 'Error al guardar',
            text: 'Ocurrió un error al guardar los datos.',
          });
        }
      });
    } else {
      console.error('No hay datos en dummyData3 para guardar');
  
      Swal.fire({
        icon: 'info',
        title: 'No hay datos',
        text: 'No hay datos para guardar.',
      });
    }
  }
  
  
  

  convertDateToMySQLFormat(date: Date): string {
    const pad = (num: number): string => (num < 10 ? '0' + num : num.toString());
    
    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);  // Los meses empiezan en 0, por eso sumamos 1
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
  
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }
  formatDateToInput(date: string | Date): string {
    if (!date || isNaN(new Date(date).getTime())) {
      return '';
    }
  
    const parsedDate = new Date(date);
    const year = parsedDate.getFullYear();
    const month = ('0' + (parsedDate.getMonth() + 1)).slice(-2);
    const day = ('0' + parsedDate.getDate()).slice(-2);
    const hours = ('0' + parsedDate.getHours()).slice(-2);
    const minutes = ('0' + parsedDate.getMinutes()).slice(-2);
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  }
  

  saveDataComm() {
    if (this.dummyData4.length > 0) {
      const com = this.dummyData4[0]; 
      const idP = localStorage.getItem('idP');
      const idP2 = idP ? parseInt(idP, 10) : null;
      const fechaMySQL = this.convertDateToMySQLFormat(new Date(com.Fecha)); 
      console.log('Contenido de com:', com);
  
      const datosAGuardar = {
        P: idP,
        Ow: com.Ow,
        ComTy: com.ComTy,
        Fecha: fechaMySQL, 
        Contenido: com.Contenido,
        Segui: com.Segui,
        Created: com.Created,
        Updated: com.Updated,
        Updated_By: com.Updated_By,
        upsize_ts: com.upsize_ts,
      };
    
      console.log('Datos a guardar:', datosAGuardar);
    
      this.apiService.postDatosCom(datosAGuardar).subscribe({
        next: (response: any) => {
          console.log('Avances: Datos guardados:', response);
  
          // Volver a cargar com
          if (idP2 !== null) {
            this.loadDataComById(idP2);
          } else {
            console.error('ID no encontrado en localStorage');
            window.location.reload();
          }
  
          // Mostrar mensaje de éxito con SweetAlert2
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Avances: Datos guardados exitosamente',
            showConfirmButton: false,
            timer: 3500
          });
  
          // Limpiar los campos después de guardar
          this.dummyData4 = [{
            Ow: '',
            ComTy: '',
            Fecha: '',
            Contenido: '',
            Segui: '',
            Created: '',
            Updated: '',
            Updated_By: '',
            upsize_ts: ''
          }];
        },
        error: (error) => {
          console.error('Error al guardar los datos:', error);
  
          // Mostrar mensaje de error con SweetAlert2
          Swal.fire({
            icon: 'error',
            title: 'Error al guardar',
            text: 'Ocurrió un error al guardar los datos.',
          });
        }
      });
    } else {
      console.error('No hay datos en dummyData4 para guardar');
  
      // Mostrar mensaje de información con SweetAlert2
      Swal.fire({
        icon: 'info',
        title: 'No hay datos',
        text: 'No hay datos para guardar.',
      });
    }
  }
  
  
  

  saveDataTo() {
    if (this.dummyData5.length > 0) {
      const element = this.dummyData5[0]; 
      const nombreUsuario = localStorage.getItem('Usuario');
      if (!nombreUsuario) {
        console.error('No se encontró Usuario en localStorage');
        return;
      }
      const idP = localStorage.getItem('idP');
      const idP2 = idP ? parseInt(idP, 10) : null;
      const datosAGuardar = {
        P: idP,
        Du: element.Du,
        Prdd: element.Prdd,
        Tarea: element.Tarea,
        Seguimiento: element.Seguimiento,
        Descripcion: element.Descripcion,
        Creado: element.Creado,
        Limite: element.Limite,
        Terminado: element.Terminado,
        Ao: element.Ao,
        Bo: element.Bo,
        Co: element.Co,
        Do: element.Do,
        Eo: element.Eo,
        Fo: element.Fo,
        Go: element.Go,
        Ho: element.Ho,
        Io: element.Io,
        Estado: element.Estado,
        Created_By: nombreUsuario,
        Created: element.Created,
        Updated_By: element.Updated_By,
        Updated: element.Updated,
      };
  
      console.log('Datos a guardar de ToDo:', datosAGuardar);
  
      this.apiService.postToDoById(datosAGuardar).subscribe({
        next: (response: any) => {
          console.log('Datos guardados de ToDo:', response);
  
          if (idP2 !== null) {
            this.loadDataToDoById(idP2);
          } else {
            console.error('ID no encontrado en localStorage');
            window.location.reload();
          }
  
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Tareas: Datos guardados exitosamente',
            showConfirmButton: false,
            timer: 3500
          });
  
          // Limpiar los campos después de guardar
          this.dummyData5 = [{
            Du: '',
            Prdd: '',
            Tarea: '',
            Seguimiento: '',
            Descripcion: '',
            Creado: '',
            Limite: '',
            Terminado: '',
            Ao: '',
            Bo: '',
            Co: '',
            Do: '',
            Eo: '',
            Fo: '',
            Go: '',
            Ho: '',
            Io: '',
            Estado: '',
            Created_By: '',
            Created: '',
            Updated_By: '',
            Updated: ''
          }];
        },
        error: (error) => {
          console.error('Error al guardar los datos de ToDo:', error);
  
          Swal.fire({
            icon: 'error',
            title: 'Error al guardar',
            text: 'Ocurrió un error al guardar los datos.',
          });
        }
      });
    } else {
      console.error('No hay datos en dummyData5 para guardar');
  
      Swal.fire({
        icon: 'info',
        title: 'No hay datos',
        text: 'No hay datos para guardar.',
      });
    }
  }
  
  
  
  saveData(element: any) {
    setTimeout(() => {
      // Formatear el upsize_ts antes de enviar los datos
      const formattedUpsizeTs = this.datePipe.transform(element.upsize_ts, 'yyyy-MM-dd HH:mm:ss');
      
      // Actualizar el elemento con el timestamp formateado
      const updatedElement = {
        ...element,
        upsize_ts: formattedUpsizeTs
      };
    
      this.apiService.putDatosCmpy(updatedElement, element.O).subscribe({
        next: (response: any) => {
          console.log('Datos guardados en save data putDatosCmpy:', response);
          // Actualizar el upsize_ts en el elemento
          element.upsize_ts = response.upsize_ts;
        },
        error: (error) => {
          if (error.status === 409) {
            console.error('Concurrencia optimista detectada. Actualizando el timestamp...');
            // Actualizar el upsize_ts desde el error de conflicto
            element.upsize_ts = error.error.entity.upsize_ts;
          } else {
            console.error('Error al guardar los datos:', error);
          }
        }
      });
    }, 500); // Retraso de 500 milisegundos (medio segundo)
  }
  

  saveDataCmpy(element: any) {
    this.apiService.putDatosLctn(element, element.Of).subscribe({
      next: (response: any) => {
        if (response) {
          console.log('Datos guardados:', response);
          // Actualizar el upsize_ts en el elemento si la respuesta no es null
          element.upsize_ts = response.upsize_ts;
        } else {
          console.log('La respuesta es null, no se puede actualizar upsize_ts');
        }
      },
      error: (error) => {
        if (error.status === 409) {
          console.error('Concurrencia optimista detectada. Actualizando el timestamp...');
          // Actualizar el upsize_ts desde el error de conflicto
          element.upsize_ts = error.error.entity.upsize_ts;
        } else {
          console.error('Error al guardar los datos:', error);
        }
      }
    });
  }

  saveDataPrsn(element: any) {
    this.apiService.putDatosPrsn(element, element.P).subscribe({
      next: (response: any) => {
        if (response) {
          console.log('Datos guardados:', response);
          // Actualizar el upsize_ts en el elemento si la respuesta no es null
          element.upsize_ts = response.upsize_ts;
        } else {
          console.log('La respuesta es null, no se puede actualizar upsize_ts');
        }
      },
      error: (error) => {
        if (error.status === 409) {
          console.error('Concurrencia optimista detectada. Actualizando el timestamp...');
          // Actualizar el upsize_ts desde el error de conflicto
          element.upsize_ts = error.error.entity.upsize_ts;
        } else {
          console.error('Error al guardar los datos:', error);
        }
      }
    });
  }
  
  saveDataCom(element: any) {
    this.apiService.putDatosCom(element, element.L).subscribe({
      next: (response: any) => {
        if (response) {
          console.log('Datos guardados:', response);
          // Actualizar el upsize_ts en el elemento si la respuesta no es null
          element.upsize_ts = response.upsize_ts;
        } else {
          console.log('La respuesta es null, no se puede actualizar upsize_ts');
        }
      },
      error: (error) => {
        if (error.status === 409) {
          console.error('Concurrencia optimista detectada. Actualizando el timestamp...');
          // Actualizar el upsize_ts desde el error de conflicto
          element.upsize_ts = error.error.entity.upsize_ts;
        } else {
          console.error('Error al guardar los datos:', error);
        }
      }
    });
  }

  saveDataTodo(element: any){
    this.apiService.putToDoById(element, element.A).subscribe({
      next: (response: any) => {
        if (response) {
          console.log('Datos guardados:', response);
          // Actualizar el upsize_ts en el elemento si la respuesta no es null
          element.upsize_ts = response.upsize_ts;
        } else {
          console.log('La respuesta es null, no se puede actualizar upsize_ts');
        }
      },
      error: (error) => {
        if (error.status === 409) {
          console.error('Concurrencia optimista detectada. Actualizando el timestamp...');
          // Actualizar el upsize_ts desde el error de conflicto
          element.upsize_ts = error.error.entity.upsize_ts;
        } else {
          console.error('Error al guardar los datos:', error);
        }
      }
    });
  }

  loadDataLctnById(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.getLctnById(id).subscribe({
        next: (data: TLocation[]) => {
          console.log("Data from API2:", data);
          const apiResponse: ApiResponseTLocation = {
            locations: data.map(item => ({ ...item, isExpanded: false }))
          };
          this.dataSourceLctnById = [apiResponse];
          this.cdr.detectChanges();
          resolve();
        },
        error: (error) => {
          console.error('Error al cargar datos de ubicaciones:', error);
          this.dataSourceLctnById = [];
          this.cdr.detectChanges();
          reject();
        }
      });
    });
  }

  loadDataPrsnById(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.getPrsnById(id).subscribe({
        next: (data: TPersona[]) => {
          console.log("Data from API3:", data);
          const apiResponse: ApiResponseTPersona = {
            personas: data.map(item => ({ ...item, isExpanded: false }))
          };
          this.dataSourcePrsnById = [apiResponse];
          this.cdr.detectChanges();
          resolve();
        },
        error: (error) => {
          console.error('Error al cargar datos de personas:', error);
          this.dataSourcePrsnById = [];
          this.cdr.detectChanges();
          reject();
        }
      });
    });
  }

   loadDataComById(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
    this.apiService.getComById(id).subscribe({
      next: (data: TContact[]) => {
        console.log("Data from API4:", data);
        const apiResponse: ApiResponseTContact = {
          contacts: data.map(item => ({ ...item, isExpanded: false }))
        };
        this.dataSourceComById = [apiResponse];
        this.cdr.detectChanges();
        resolve();
      },
      error: (error) => {
        console.error('Error al cargar datos de contactos:', error);
        this.dataSourceComById = [];
        this.cdr.detectChanges();
        reject();
      }
    });
  });
  }
  loadDataToDoById(id: number): Promise<void> {
    return new Promise((resolve, reject) => {
      this.apiService.getToDoById(id).subscribe({
        next: (data: any) => {  // Usa `any` para manejar tanto objetos como arrays
          console.log("Data from API5:", data);
          //log de A y de Tarea
          console.log("Data from API5 A(only one element):", data[0].A);
console.log("Data from API5 Tarea(only one element):", data[0].Tarea);

          if (Array.isArray(data)) {
            const apiResponse: ApiResponseToDo = {
              todos: data.map(item => ({ ...item, isExpanded: false }))
            };
            this.dataSourceToDoById = [apiResponse];
          } else if (data && typeof data === 'object') {
            const apiResponse: ApiResponseToDo = {
              todos: [{ ...data, isExpanded: false }]  // Envolviendo el objeto en un array
            };
            this.dataSourceToDoById = [apiResponse];
          } else {
            console.error('La respuesta de la API no es válida:', data);
            this.dataSourceToDoById = [];
          }
          this.cdr.detectChanges();
          resolve();
        },
        error: (error) => {
          console.error('Error al cargar datos de ToDos:', error);
          this.dataSourceToDoById = [];
          this.cdr.detectChanges();
          reject();
        }
      });
    });
  }
  
  
  
  
  loadTestData() {
    this.dataSourceTest1 = [
      { o: 1, nombre: 'Producto A', type: 'Tipo 1' },
      { o: 2, nombre: 'Producto B', type: 'Tipo 2' }
    ];
  }

  currentExpandedElement: any = null;
  currentExpandedLctn: any = null;

  AddtoggleRow(element: any) {

    this.dataSourceLctnById = [];
    this.dataSourcePrsnById = [];
    this.dataSourceComById = [];
    this.dataSourceToDoById = [];
    if (this.currentExpandedElement && this.currentExpandedElement !== element) {
      this.currentExpandedElement.isExpanded = false;
    }
    element.isExpanded = !element.isExpanded;

    if (element.isExpanded) {
      this.currentExpandedElement = element;
      this.loadDataLctnById(element.O).then(() => {
        if (this.dataSourceLctnById.length > 0 && this.dataSourceLctnById[0].locations.length > 0) {
          const firstLctn = this.dataSourceLctnById[0].locations[0];
          this.toggleRow2(firstLctn, true);
        }
      });
    } else {
      this.currentExpandedElement = null;
    }
    console.log("ID: " + element.O);
    console.log("Element: ", element.Nombre);
    console.log("isExpanded: " + element.isExpanded);
  }

  toggleRow(element: any) {
    // Restablecer la selección de otros elementos en la misma tabla
    this.dataSource.data.forEach(row => {
      if (row !== element) {
        row.isExpanded = false;
        row.isSelected = false;
      }
    });

    // Alternar expansión y selección
    element.isExpanded = !element.isExpanded;
    element.isSelected = element.isExpanded;

    if (element.isExpanded) {
      this.currentExpandedElement = element;
      const cmpyId = element.O;
      localStorage.setItem('cmpyId', cmpyId);
      this.cmpyId = cmpyId;

      // Cargar datos adicionales si es necesario
      this.loadDataLctnById(cmpyId).then(() => {
        // Tu código existente
      });
    } else {
      this.currentExpandedElement = null;
    }
  }
  




  
  
  
  

  toggleRow2(lctn: any, auto: boolean = false) {
    console.log('Toggling row for:', lctn.Name); // Para depuración
    
    // Si hay una fila expandida diferente a la actual, colapsamos la anterior
    if (this.currentExpandedLctn && this.currentExpandedLctn !== lctn) {
      this.currentExpandedLctn.isExpanded = false;
      console.log('Colapsando la fila previa:', this.currentExpandedLctn.Name); // Depuración
    }
  
    // Cambiar el estado de expansión del elemento actual
    if (!auto) {
      lctn.isExpanded = !lctn.isExpanded;
      console.log(`Nueva expansión de ${lctn.Name}:`, lctn.isExpanded); // Depuración
    } else {
      lctn.isExpanded = true;
    }
  
    // Si está expandido, guardamos el elemento actual como expandido
    if (lctn.isExpanded) {
      this.currentExpandedLctn = lctn;
      console.log('Expandiendo fila:', lctn.Name); // Depuración
  
      // Cargamos los datos asociados a esta locación (si es necesario)
      this.loadDataPrsnById(lctn.Of).then(() => {
        if (this.dataSourcePrsnById.length > 0 && this.dataSourcePrsnById[0].personas.length > 0) {
          const firstPrsn = this.dataSourcePrsnById[0].personas[0];
          this.toggleRow3(firstPrsn, true);
        }
      });
    } else {
      this.currentExpandedLctn = null; // Si está colapsado, limpiamos la referencia
      console.log('Colapsando fila:', lctn.Name); // Depuración
    }
  
    // Guardar el ID de la locación para uso posterior
    localStorage.setItem('idOf', lctn.Of);
    const idOf = localStorage.getItem('idOf');
    console.log("ID de la locación almacenada: " + idOf);
    console.log("Estado final de isExpanded para " + lctn.Name + ": " + lctn.isExpanded);
  }
  
  

  toggleRow3(prsn: any, auto: boolean = false) {
    if (this.currentExpandedLctn && this.currentExpandedLctn !== prsn) {
      this.currentExpandedLctn.isExpanded = false;
    }
    if (!auto) {
      prsn.isExpanded = !prsn.isExpanded;
    } else {
      prsn.isExpanded = true;
    }
    if (prsn.isExpanded) {
      this.currentExpandedLctn = prsn;
      this.loadDataComById(prsn.P).then(() => {
        if (this.dataSourceComById.length > 0 && this.dataSourceComById[0].contacts.length > 0) {
          const firstCom = this.dataSourceComById[0].contacts[0];
          this.toggleRow4(firstCom, true);
        }
      });
    } else {
      this.currentExpandedLctn = null;
    }

    localStorage.setItem('idP', prsn.P);
    const idP = localStorage.getItem('idP');
    console.log("ID de la locación: " + idP);
    console.log("ID: " + prsn.P);
    console.log("Element prsn: ", prsn.Nombre);
    console.log("isExpanded: " + prsn.isExpanded);
  }

  toggleRow4(prsn: any, auto: boolean = false) {
    if (this.currentExpandedLctn && this.currentExpandedLctn !== prsn) {
      this.currentExpandedLctn.isExpanded = false;
    }
    prsn.isExpanded = !prsn.isExpanded;
    if (prsn.isExpanded) {
      this.currentExpandedLctn = prsn;
      this.loadDataToDoById(prsn.P);
      console.log("ID desde toggleRow4: " + prsn.P);
    } else {
      this.currentExpandedLctn = null;
    }
    
    //localStorage.setItem('idP', prsn.P);
    const idP = localStorage.getItem('idP');
    console.log("ID de la locación: " + idP);
    console.log("ID: " + prsn.P);
    console.log("Element prsn: ", prsn.Contenido);
    console.log("isExpanded: " + prsn.isExpanded);
  }
  toggleRow5(todo: any) {
    if (this.currentExpandedToDo && this.currentExpandedToDo !== todo) {
      this.currentExpandedToDo.isExpanded = false;
    }
    todo.isExpanded = !todo.isExpanded;
    if (todo.isExpanded) {
      this.currentExpandedToDo = todo;
      // Aquí podrías cargar más detalles si es necesario
      // this.loadDataToDoById(todo.id).subscribe(); // Ejemplo de carga adicional si es necesario
    } else {
      this.currentExpandedToDo = null;
    }
    
    console.log("ID: " + todo.p);
    console.log("Element todo: ", todo.Tarea);
    console.log("isExpanded: " + todo.isExpanded);
  }
  logId(o: any) {
    console.log("ID: " + o);
  }

  isExpansionDetailRow = (i: number, row: any) => row.hasOwnProperty('isExpanded');

  applyFilter1() {
    const filterValue = this.searchTerm1.trim().toLowerCase();
    if (filterValue === '') {
      // Restaurar dataSource a su estado original
      this.dataSource.data = [...this.originalDataSource];
    } else {
      // Filtrar dataSource basado en el valor de búsqueda
      this.dataSource.data = this.originalDataSource.filter((item: any) =>
        (item.o && item.o.toString().toLowerCase().includes(filterValue)) ||
        (item.Nombre && item.Nombre.toLowerCase().includes(filterValue))
      );
    }
  }
  
  // En tu componente TypeScript
  onSharedWithOptionChange(event: any, option: string) {
    option = option.toLowerCase();
    if (event.checked) {
      this.selectedSharedWithOptions.push(option);
    } else {
      const index = this.selectedSharedWithOptions.indexOf(option);
      if (index !== -1) {
        this.selectedSharedWithOptions.splice(index, 1);
      }
    }
    
    // Actualiza las iniciales seleccionadas
    this.updateSelectedInitials();
    this.applyFilters();
  }
  
  updateSelectedInitials() {
    // Concatenar las iniciales de los usuarios seleccionados
    this.selectedInitials = this.selectedSharedWithOptions.join(', ');
  }
  
  clearFilters1() {
    this.selectedSharedWithOptions = []; // Limpia las opciones seleccionadas
  this.selectedInitials = ''; // Limpia las iniciales mostradas
  this.applyFilters(); // Vuelve a aplicar los filtros si es necesario
  }
  

applyFilters() {
  let filteredData = [...this.originalDataSource];

  // Aplicar filtro de texto
  if (this.searchTerm1) {
    const filterValue = this.searchTerm1.trim().toLowerCase();
    filteredData = filteredData.filter((item: any) =>
      (item.o && item.o.toString().toLowerCase().includes(filterValue)) ||
      (item.Nombre && item.Nombre.toLowerCase().includes(filterValue))
    );
  }

  // Aplicar filtro de Shared_With
  if (this.selectedSharedWithOptions.length > 0) {
    filteredData = filteredData.filter((item: any) => {
      if (item.Shared_With) {
        const sharedWithArray = item.Shared_With.split(';').map((s: string) => s.trim().toLowerCase());
        return this.selectedSharedWithOptions.some(option => sharedWithArray.includes(option));
      }
      return false;
    });
  }

  // Actualizar el dataSource
  this.dataSource.data = filteredData;
}

  applyFilter2() {
    const filterValue = this.searchTerm2.trim().toLowerCase();
    if (filterValue === '') {
      this.dataSource.data = [...this.originalDataSource];
      
    } else {
      this.dataSourceLctnById.forEach(apiResponse => {
        apiResponse.locations = apiResponse.locations.filter((item: any) =>
         
          (item.Of && item.Of.toString().toLowerCase().includes(filterValue)) ||
          (item.Name && item.Name.toLowerCase().includes(filterValue))
        );
      });
    }
    
  }

  applyFilter3() {
    const filterValue = this.searchTerm3.trim().toLowerCase();
    if (filterValue === '') {
      this.dataSource.data = [...this.originalDataSource];
      
    } else {
      this.dataSourcePrsnById.forEach(apiResponse => {
        apiResponse.personas = apiResponse.personas.filter((item: any) =>
         
          (item.P && item.Nombre.toString().toLowerCase().includes(filterValue)) ||
          (item.P && item.Nombre.toLowerCase().includes(filterValue))
        );
      });
    }
    
  }

  applyFilter4() {
    const filterValue = this.searchTerm4.trim().toLowerCase();
    if (filterValue === '') {
      this.dataSource.data = [...this.originalDataSource];
      
    } else {
      this.dataSourceComById.forEach(apiResponse => {
        apiResponse.contacts = apiResponse.contacts.filter((item: any) =>
         
          (item.L && item.L.toString().toLowerCase().includes(filterValue)) 
        );
      });
    }
    
  }
  
  applyFilterToDo() {
    const filterValue = this.searchTerm4.trim().toLowerCase();
    if (filterValue === '') {
      this.dataSourceToDoById = [...this.originalDataSourceToDoById];
    } else {
      this.dataSourceToDoById = this.originalDataSourceToDoById.filter((item: any) =>
        item.p.toString().includes(filterValue) ||
        item.Tarea.toLowerCase().includes(filterValue)
      );
    }
  }

  clearFilters() {
    this.searchTerm = '';
    this.searchTerm1 = '';
    this.searchTerm2 = '';
    this.searchTerm3 = '';
    this.searchTerm4 = '';
    this.dataSource.data = [...this.originalDataSource];
    this.dataSourceLctnById = [...this.originalDataSourceLctnById];
    this.dataSourcePrsnById = [...this.originalDataSourcePrsnById];
    this.dataSourceComById = [...this.originalDataSourceComById];
    this.loadData();
  }

  dummyData: any[] = [
    {
      Nombre: '',
      Rs: '',
      Ac: false,
      Type: '',
      Industry: '',
      SerPro: '',
      Origen: '',
      URL: '',
      Linkedin: '',
      eMail: '',
      Fnd: '',
      Emplea: '',
      Ventas: '',
      Ref: '',
      Nota: '',
      Company_State: '',
      Shared_With: '',
      Created_By: '',
      Created: '',
      elementShared: {
        option5: false,
        option6: false,
        option7: false,
        option8: false,
        option9: false,
        option10: false,
        option11: false,
      },

    }
  ]; // Datos iniciales de ejemplo

  dummyData2: any[] = [
    {
      Nombre: '',
      URL: '',
      SWB: '',
      SWB2: '',
      Domicilio: '',
      Colonia: '',
      City: '',
      State: '',
      Pais: ''
    }
  ];

  dummyData3: any[] = [
    {
      Nombre: '',
      Segundo: '',
      APaterno: '',
      AMaterno: '',
      Prefijo: '',
      Sufijo: '',
      Puesto: '',
      Ext: '',
      Linkedin: '',
      TCel1: '',
      TSwB: '',
      TOf: '',
      TAssist: '',
      TOf2: '',
      T: '',
      TCel2: '',
      THome: '',
      TFax: '',
      eMailw: '',
      eMailp: '',
      Asistente: '',
      When: '',
      Where: ''
    }
  ];
  
  dummyData4: any[] = [
    {
      Ow: '',
      ComTy: '',
      Fecha: '',
      Contenido: '',
      Segui: '',
      Created: '',
      Updated: '',
      Updated_By: '',
      upsize_ts: ''
    }
  ];

  dummyData5: any[] = [
    {
      Du: '',
      Prdd: '',
      Tarea: '',
      Seguimiento: '',
      Descripcion: '',
      Creado: '',
      Limite: '',
      Terminado: '',
      Ao: '',
      Bo: '',
      Co: '',
      Do: '',
      Eo: '',
      Fo: '',
      Go: '',
      Ho: '',
      Io: '',
      Estado: '',
      Created_By: '',
      Created: '',
      Updated_By: '',
      Updated: ''
    }
  ];

  //modal checkbox
  onCheckboxChangeA(event: any) {
    if (event.target.checked) {
      this.showModal1();
    }
  }

  onCheckboxChangeB(event: any) {
    if (event.target.checked) {
      this.showModal2();
    }
  }
  
  onCheckboxChangeC(event: any) {
    if (event.target.checked) {
      this.showModal3();
    }
  }
  onCheckboxChangeD(event: any) {
    if (event.target.checked) {
      this.showModal4();
    }
  }
  onCheckboxChangeE(event: any) {
    if (event.target.checked) {
      this.showModal5();
    }
  }
  onCheckboxChangeF(event: any) {
    if (event.target.checked) {
      this.showModal6();
    }
  }
  onCheckboxChangeG(event: any) {
    if (event.target.checked) {
      this.showModal7();
    }
  }
  onCheckboxChangeH(event: any) {
    if (event.target.checked) {
      this.showModal8();
    }
  }
  onCheckboxChangeI(event: any) {
    if (event.target.checked) {
      this.showModal9();
    }
  }


  showModal1() {
    const modalElement = document.getElementById('confirmationModal');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal2() {
    const modalElement = document.getElementById('confirmationModalb');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal3() {
    const modalElement = document.getElementById('confirmationModalc');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal4() {
    const modalElement = document.getElementById('confirmationModald');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal5() {
    const modalElement = document.getElementById('confirmationModale');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal6() {
    const modalElement = document.getElementById('confirmationModalf');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal7() {
    const modalElement = document.getElementById('confirmationModalg');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal8() {
    const modalElement = document.getElementById('confirmationModalh');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  showModal9() {
    const modalElement = document.getElementById('confirmationModali');
    if (modalElement) {
      // Usa JavaScript puro para mostrar el modal
      const modal = new (window as any).bootstrap.Modal(modalElement);
      modal.show();
    }
  }
  
  cambiarAc(acValue: boolean, id: number): void {
    console.log('Valor de Ac antes de cambiar:', acValue);
    console.log('ID (O):', id);
  
    // Cambiar el valor de Ac al opuesto
    const nuevoAcValue = !acValue;

    console.log('Nuevo valor de Ac:', nuevoAcValue);

    // Llamar al método patchAc del ApiService para actualizar el valor de Ac en el backend
    this.apiService.patchAc(id, nuevoAcValue).subscribe(
      response => {
        console.log('Actualización exitosa:', response);
        this.loadData(); // Recargar los datos después de actualizar
      },
      error => {
        console.error('Error al actualizar:', error);
      }
    );
}

deleteElement(id: number) {
  if (confirm('¿Estás seguro de que quieres eliminar este elemento?')) {
    console.log('ID del elemento:', id); 
    this.apiService.deleteCmpy(id).subscribe({
      next: () => {
        this.apiService.deleteLctn(id).subscribe({
          next: () => {
            this.apiService.deletePrsn(id).subscribe({
              next: () => {
                this.loadData();
                this.toastr.success('Elemento y datos anidados eliminados exitosamente');
              },
              error: (error) => {
                console.error('Error al eliminar datos de persona:', error);
                this.toastr.error('Error al eliminar datos de persona');
              }
            });
          },
          error: (error) => {
            console.error('Error al eliminar datos de ubicación:', error);
            this.toastr.error('Error al eliminar datos de ubicación');
          }
        });
      },
      error: (error) => {
        console.error('Error al eliminar el elemento:', error);
        this.toastr.error('Error al eliminar el elemento');
      }
    });
  }
}

getCurrentId(): number {
  const id = localStorage.getItem('idO');
  return id ? parseInt(id, 10) : 0;
}

// Función para eliminar la ubicación
deleteLocation(element: any) {
    //declarar idO2 y que tenga el valor de element.O
  const idO2 = element.O;
  console.log('ID seleccionado:', element.Of);
  this.apiService.deleteLctn(element.Of).subscribe({
    next: () => {
      this.loadData();
      this.toastr.info('Ubicación eliminada exitosamente');
      if (idO2 !== null) {
        this.loadDataLctnById(idO2);  // Solo llama a la función si idO2 no es null
      } else {
        console.error('ID no encontrado en localStorage');
        //recargar la página
        window.location.reload();
      }
    },
    error: (error) => {
      console.error('Error al eliminar la ubicación:', error);
      this.toastr.error('Error al eliminar la ubicación');
    }
  });
}

//Función para eliminar la persona prsn 
detelePerson(element: any) {
  const idOf = element.Of;
  console.log('ID seleccionado:', element.P);
  this.apiService.deletePrsn(element.P).subscribe({
    next: () => {
      this.loadData();
      this.toastr.info('Persona eliminada exitosamente');
      if (idOf !== null) {
        this.loadDataPrsnById(idOf);  // Solo llama a la función si idOf2 no es null
      } else {
        console.error('ID no encontrado en localStorage');
        //recargar la página
        window.location.reload();
      }
    },
    error: (error) => {
      console.error('Error al eliminar la persona:', error);
      this.toastr.error('Error al eliminar la persona');
    }
  });
}

deleteAvance(element: any){
  const idP = element.L;
  console.log('ID seleccionado:', element.L);
  this.apiService.deleteCom(element.L).subscribe({
    next: () => {
      this.loadData();
      this.toastr.info('Avance eliminado exitosamente');
      if (idP !== null) {
        this.loadDataComById(idP);  // Solo llama a la función si idOf2 no es null
      } else {
        console.error('ID no encontrado en localStorage');
        //recargar la página
        window.location.reload();
      }
    },
    error: (error) => {
      console.error('Error al eliminar el Avance:', error);
      this.toastr.error('Error al eliminar el Avance');
    }
  });
}
deletetoDo(element: any){
  const idP = element.P;
  console.log('ID seleccionado:', element.P);
  this.apiService.deletetoDo(element.P).subscribe({
    next: () => {
      this.loadData();
      this.toastr.info('Tarea eliminado exitosamente');
      if (idP !== null) {
        this.loadDataToDoById(idP);  // Solo llama a la función si idOf2 no es null
      } else {
        console.error('ID no encontrado en localStorage');
        //recargar la página
        window.location.reload();
      }
    },
    error: (error) => {
      console.error('Error al eliminar el Tarea:', error);
      this.toastr.error('Error al eliminar el Tarea');
    }
  });
}

elementShared = {
 
  option5: false,
  option6: false,
  option7: false,
  option8: false,
  option9: false,
  option10: false,
  option11: false,
};

// Al cargar los datos, marcamos las opciones correctas
loadSharedWith(sharedWith: string) {
  const selected = sharedWith.split(';');

  
  this.elementShared.option6 = selected.includes('cjr');
  this.elementShared.option7 = selected.includes('dso');
  this.elementShared.option8 = selected.includes('lep');
  this.elementShared.option9 = selected.includes('nty');
  this.elementShared.option10 = selected.includes('dair');
  this.elementShared.option11 = selected.includes('eca');
}

// Actualizamos element.Shared_With en lugar de selectedOptions
updateSelection(element: any) {
  const selected: string[] = ['ety', 'aty','bjr','dcj']; // Agregar valores fijos
  
  if (!element.elementShared) {
    element.elementShared = {
      option5: false,
      option6: false,
      option7: false,
      option8: false,
      option9: false,
      option10: false,
      option11: false,
    };
  } // Mover la llave de cierre aquí

  // Obtener el usuario actual
  const nombreUsuario = localStorage.getItem('Usuario');
  if (nombreUsuario) {
    selected.push(nombreUsuario);
  } else {
    console.error('No se encontró Usuario en localStorage');
  }

  // Agregar opciones seleccionadas por el usuario

  if (element.elementShared.option6) {
    selected.push('cjr');
  }
  if (element.elementShared.option7) {
    selected.push('dso');
  }
  if (element.elementShared.option8) {
    selected.push('lep');
  }
  if (element.elementShared.option9) {
    selected.push('nty');
  }
  if (element.elementShared.option10) {
    selected.push('dair');
  }
  if (element.elementShared.option11) {
    selected.push('eca');
  }

  // Eliminar duplicados
  const uniqueSelected = Array.from(new Set(selected));

  // Concatenar las opciones seleccionadas y asignarlas a element.Shared_With
  element.Shared_With = uniqueSelected.join(';');

  console.log('Opciones seleccionadas:', element.Shared_With);
}



newElementShared = {
  option5: false,
  option6: false,
  option7: false,
  option8: false,
  option9: false,
  option10: false,
  option11: false,
};

// Object to hold the new element's data
newElement = {
  Shared_With: '',
  // Include other fields as necessary
};
// Function to update the Shared_With field based on selected checkboxes
updateNewSelection() {
  const selected: string[] = ['ety', 'aty', 'dcj']; // Agregar valores fijos

  // Obtener el usuario actual
  const nombreUsuario = localStorage.getItem('Usuario');
  if (nombreUsuario) {
    selected.push(nombreUsuario);
  } else {
    console.error('No se encontró Usuario en localStorage');
  }

  // Agregar opciones seleccionadas por el usuario
  

  if (this.newElementShared.option6) {
    selected.push('cjr');
  }
  if (this.newElementShared.option7) {
    selected.push('dso');
  }
  if (this.newElementShared.option8) {
    selected.push('lep');
  }
  if (this.newElementShared.option9) {
    selected.push('nty');
  }
  if (this.newElementShared.option10) {
    selected.push('dair');
  }
  if (this.newElementShared.option11) {
    selected.push('eca');
  }

  // Eliminar duplicados en caso de que existan
  const uniqueSelected = Array.from(new Set(selected));

  // Concatenar las opciones seleccionadas y asignarlas a newElement.Shared_With
  this.newElement.Shared_With = uniqueSelected.join(';');

  console.log('Opciones seleccionadas:', this.newElement.Shared_With);
}



}
