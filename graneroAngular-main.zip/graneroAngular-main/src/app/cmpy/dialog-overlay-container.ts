import { OverlayContainer } from '@angular/cdk/overlay';

export class DialogOverlayContainer extends OverlayContainer {
  protected override _createContainer(): void {
    const container = document.createElement('div');
    container.classList.add('cdk-overlay-container');
    this._containerElement = container;

    const parentElement = document.querySelector('.cdk-global-overlay-wrapper') || document.body;
    parentElement.appendChild(this._containerElement);
  }
}
