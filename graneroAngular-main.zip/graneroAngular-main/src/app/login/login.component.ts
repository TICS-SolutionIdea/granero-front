import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MyApiService } from '../api/my-api-service.service'; // Asegúrate de que esta ruta sea correcta
import { Router } from '@angular/router';  // Importar Router


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule],
  providers: [MyApiService]
})
export class LoginComponent implements OnInit {
  loginData = {
    username: '',
    password: ''
  };
  nombreUsuario: string | null = '';
  usuario: string | null = '';
  isExpanded: boolean = false;

  constructor(private apiService: MyApiService, private router: Router) { }

  ngOnInit() {
    this.nombreUsuario = localStorage.getItem('Nombre_Usuario');
    this.usuario = localStorage.getItem('Usuario');

    if (this.nombreUsuario && this.usuario) {
      console.log("Nombre_Usuario guardado:", this.nombreUsuario);
      console.log("Usuario guardado:", this.usuario);
      
      // Redirigir a /cmpy si hay sesión iniciada
      this.router.navigate(['/cmpy']);
    } else {
      console.log("Aún no ha iniciado sesión");
    }
  }

  signIn(loginForm: any) {
    if (loginForm.valid) {
      this.apiService.signIn(this.loginData).subscribe({
        next: (response) => {
          console.log("Inicio de sesión exitoso: ", response);
          const userData = response.user;
          console.log("Datos del usuario:", userData);
          
          // Guardar en localStorage
          localStorage.setItem('Nombre_Usuario', userData.Nombre_Usuario);
          localStorage.setItem('Usuario', userData.Usuario);

          // Actualizar propiedades
          this.nombreUsuario = userData.Nombre_Usuario;
          this.usuario = userData.Usuario;

          // Mostrar datos guardados en consola
          console.log("Nombre_Usuario guardado:", this.nombreUsuario);
          console.log("Usuario guardado:", this.usuario);
        },
        error: (error) => {
          console.error("Error al iniciar sesión: ", error);
        }
      });
    } else {
      console.warn("Formulario de inicio de sesión inválido");
    }
  }

  signOut() {
    // Eliminar datos de sesión
    localStorage.removeItem('Nombre_Usuario');
    localStorage.removeItem('Usuario');
    localStorage.removeItem('isLoggedIn');  // Eliminar el estado de sesión iniciada
    this.nombreUsuario = null;
    this.usuario = null;

    // Redirigir al login
    this.router.navigate(['/login']);
    console.log("Sesión cerrada");
  }

  toggleExpansion(): void {
    this.isExpanded = !this.isExpanded;
  }
}
